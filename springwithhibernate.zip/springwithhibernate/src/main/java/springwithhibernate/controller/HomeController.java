package springwithhibernate.controller;


import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import springwithhibernate.dao.DaoImpl;
import springwithhibernate.dao.DaoInterface;
import springwithhibernate.model.Student;

@Controller
public class HomeController 
{


	DaoInterface di = null;

	
	  @RequestMapping("/reqreg")
	  public String register(@RequestParam("t1") String  sid,@RequestParam("t2") String sname,@RequestParam("t3") int marks,@RequestParam("t4") String city)
	  { 
		  boolean b=false; Student s=new
	      Student(); s.setSid(sid); s.setSname(sname); s.setMarks(marks);
	  s.setCity(city);
	  di=new DaoImpl(); 
	  b=di.register(s); 
	  if(b) 
		  return "welcome.jsp"; 
	  else 
		  return "index.jsp";
	  
	  }
	  
	  @RequestMapping("/reqallstudent")
	  public ModelAndView viewAllStudents()
	  {
		  List<Student> students=null;
		  di=new DaoImpl();
		  students=di.selectAllStudents();
		  ModelAndView mav=new ModelAndView();
		  mav.addObject("students",students);
		  mav.setViewName("allStudents.jsp");
		  return mav;
	  }
	  
	  @RequestMapping("/reqsearch")
	  public ModelAndView search(@RequestParam("search") String search)
	  {
		  Student student=null;
		  di=new DaoImpl();
		  student=di.search(search);
		  ModelAndView mav=new ModelAndView();
		  mav.addObject("student",student);
		  mav.setViewName("search.jsp");
		  
		  return mav;
	  }
	 
	  
	  @RequestMapping("/reqdelete")
	  public String deleteStudent(@RequestParam("sid") String sid)
	  {
		  boolean b=false;
		  di=new DaoImpl();
		  b=di.deleteStudent(sid);
		  if(b)
			  return "hai";
		  else
			  return "index.jsp";
		  
	  }

	  @RequestMapping("/requpdate")
	 public ModelAndView getDataToUpdate(@RequestParam("sid") String sid)
	 {
		 Student s=null;
		  di=new DaoImpl();
		  System.out.println("sid: "+sid);
		 s=di.search(sid);
		 System.out.println(s);
		 ModelAndView mav=new ModelAndView();
		 mav.addObject("student",s);
		 mav.setViewName("updateform.jsp");
		 return mav;
		 
		 
	 }
	  
	  public void update()
	  {
		  
	  }

}
