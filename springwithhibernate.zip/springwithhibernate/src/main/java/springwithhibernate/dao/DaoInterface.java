package springwithhibernate.dao;
import java.util.List;

import springwithhibernate.model.Student;
public interface DaoInterface 
{
	public boolean register(Student s);
	public List<Student> selectAllStudents();
	public Student search(String sid);
	public boolean deleteStudent(String sid);
	public Student getData(String sid);
}
