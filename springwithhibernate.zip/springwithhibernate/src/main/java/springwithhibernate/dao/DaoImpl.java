 package springwithhibernate.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import springwithhibernate.model.Student;

public class DaoImpl implements DaoInterface
{
    SessionFactory sf=null;
    public DaoImpl()
    {
    	Configuration cfg=new Configuration().configure().addAnnotatedClass(Student.class);
    	sf=cfg.buildSessionFactory();
    }
	public boolean register(Student s) 
	{
		boolean b=false;
        Session session=sf.openSession();
        Transaction tx=session.beginTransaction();
        Object obj =session.save(s);
        if(obj!=null)
        	b=true;
        tx.commit();
        session.close();
		
		return b;
	}
	public List<Student> selectAllStudents() 
	{
		Session session=sf.openSession();
		Query query=session.createQuery("from Student");
		List<Student> students=query.list();
	
		return students;
	}
	public Student search(String sid) 
	{
		Student student=null;
		Session session=sf.openSession();
		student=(Student)session.get(Student.class, sid);
		session.close();
		return student;
	}
	public boolean deleteStudent(String sid) 
	{
		Student s=new Student();
		s.setSid(sid);
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.delete(s);  
		tx.commit();
		session.close();
		
		return false;
	}
	public Student getData(String sid) 
	{
		Student student=null;
		Session session=sf.openSession();
		student=(Student)session.get(Student.class, sid);
		session.close();
		return student;
	}

}
