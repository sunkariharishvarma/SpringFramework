package org.niit.springexample1;

public class DI {

	public static void main(String[] args) 
	{
App obj=new App();
obj.myDraw(new Circle());

	}

}
