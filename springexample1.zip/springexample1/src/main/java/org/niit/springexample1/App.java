package org.niit.springexample1;

public class App 
{

	public void myDraw(Shape shape)   
	{
		shape.draw();
	}
}
