package org.niit.springexample1;

public interface Shape
{
	void draw();

}
