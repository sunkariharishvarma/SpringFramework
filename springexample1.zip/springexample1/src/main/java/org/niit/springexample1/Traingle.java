package org.niit.springexample1;

public class Traingle implements Shape
{
	
	public void draw()
	{
		System.out.println("this is draw() of Trianlge class");
	}
}
